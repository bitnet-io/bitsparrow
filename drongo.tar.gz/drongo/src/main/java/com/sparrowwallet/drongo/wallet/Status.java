package com.sparrowwallet.drongo.wallet;

public enum Status {
    FROZEN
}
