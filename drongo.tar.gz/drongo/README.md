# Drongo

Drongo is a Java Bitcoin library built mainly to support [Sparrow Wallet](https://sparrowwallet.com).

## Building

Drongo can be built with

`./gradlew shadowJar`

## License

Drongo is licensed under the Apache 2 software licence.

## Credits

Drongo was inspired by (and is in part derived from) by the [BitcoinJ](https://bitcoinj.github.io/) Bitcoin library.  